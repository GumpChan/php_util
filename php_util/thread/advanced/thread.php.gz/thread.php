<?php
class test extends Thread
{
	public function run ()
	{
		date_default_timezone_set("UTC");
		$i = 0;
		echo "running!!{$i}\n";
		$i ++;
		sleep(1);
		echo strtotime("now")."\n";
		//return true;
	}
}
function main()
{
	//date_default_timezone_set("UTC");
	$nuts = array();
	$test = new test();
	for($i=0;$i<20;$i++){
		$tmp = new test();
		array_push($nuts,$tmp);
	}
	foreach($nuts as $value){
		$value->start();
	}
}
main();
?>

