<?php
	class farmer extends Worker 
	{
		public function run()
		{
			$i=0;
			echo "running{$i}!!\n";
			$i++;
			//echo strtotime(now());
		}
	}
	function main()
	{
	//	date_default_timezone_set("UTC");
		$test = new farmer();
		$run = new farmer();
		$run1 = new farmer();
		$test->stack($run);
		$test->stack($run1);
		$test->start();
		while(1){
			if($run->isRunning()){
				echo "{$run->getThreadId()}is running!!\n";
				echo "{$run1->getThreadId()}";
			}
		//	echo "{$run->getThreadId()}\n";
	//		sleep(5);
		} 
	}
	main();
?>
